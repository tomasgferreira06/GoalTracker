package com.example.gps_g12.goalTracker.model.fsm;

public enum EState {

    LIST_TASKS,
    ADD_TASKS,
    EDIT_TASK,
    DELETE_TASK,
    PROFILE
}
