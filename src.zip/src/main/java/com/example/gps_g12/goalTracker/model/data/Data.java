package com.example.gps_g12.goalTracker.model.data;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class Data {

    User user;

    public Data(){
        this.user = new User();
        loadTasksFromFile();
    }

    public ArrayList<Task> getUserTasks(){return user.getTasks();}

    public void addNewTask(Task newTask){
        user.addNewTask(newTask);
        saveNewTaskOnFile(newTask);
    }

    public void saveNewTaskOnFile(Task newTask) {
        try (BufferedReader reader = new BufferedReader(new FileReader("tasks.txt"))) {
            ArrayList<String> lines = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }

            // Adicione os detalhes da nova tarefa à lista
            String newTaskLine = newTask.getId() + "," + newTask.getName() + "," + newTask.getDate().getDay() + "/" + newTask.getDate().getMonth() + "/" + newTask.getDate().getYear() + "," + newTask.getHour().getHours() + ":" + newTask.getHour().getMinutes() + "," + newTask.getFrequency() + "," + newTask.getPriority() + "," + newTask.getTimesPerDay() + "," + newTask.getReminder() + "," + newTask.isCompleted();
            lines.add(0, newTaskLine);

            // Reescreva todo o conteúdo do arquivo
            try (PrintWriter writer = new PrintWriter(new FileWriter("tasks.txt", false))) {
                for (String fileLine : lines) {
                    writer.println(fileLine);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            // Trate a exceção apropriadamente para a sua aplicação
        }
    }


    public void loadTasksFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader("tasks.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);

                if(taskDetails.length > 1 && !taskDetails[taskDetails.length -1].equals("true")){
                    try {
                        // Crie uma nova instância de Task usando os detalhes do arquivo
                        Task loadedTask = new Task(
                                taskDetails[1],  // Nome
                                new Date(Integer.parseInt(taskDetails[2].split("/")[0]), Integer.parseInt(taskDetails[2].split("/")[1]), Integer.parseInt(taskDetails[2].split("/")[2])),  // Data
                                new Hour(Integer.parseInt(taskDetails[3].split(":")[0]), Integer.parseInt(taskDetails[3].split(":")[1])),  // Hora
                                taskDetails[4],  // Frequência
                                taskDetails[5],  // Prioridade
                                Integer.parseInt(taskDetails[6]),  // Vezes por dia
                                Boolean.parseBoolean(taskDetails[7])  // Lembrete
                        );
                        // Adicione a tarefa carregada à lista de tarefas do usuário

                        //TODO adicionar a lista de tarefas correta consoante o dia

                        int loadedDayFromFile = Integer.parseInt(taskDetails[2].split("/")[0]);
                        int loadedMonthFromFile = Integer.parseInt(taskDetails[2].split("/")[1]);
                        int loadedYearFromFile = Integer.parseInt(taskDetails[2].split("/")[2]);

                        LocalDate systemDate = LocalDate.now();

                        int systemDay = systemDate.getDayOfMonth();
                        int systemMonth = systemDate.getMonthValue();
                        int systemYear = systemDate.getYear();

                        if(systemDay == loadedDayFromFile  && systemMonth == loadedMonthFromFile && systemYear == loadedYearFromFile){ //today
                            user.addToTodayTasks(loadedTask);
                        }else if(systemDay + 1 == loadedDayFromFile && systemMonth == loadedMonthFromFile && systemYear == loadedYearFromFile){ //tomorrow
                            user.addToTomorrowTasks(loadedTask);
                        }else if(loadedDayFromFile == 0 && loadedMonthFromFile == 0 && loadedYearFromFile == 0){ //no spec date
                            user.addToNoSpecDateTasks(loadedTask);
                        }else{ //random day
                            user.addNewTask(loadedTask);
                        }

                        //user.addNewTask(loadedTask);
                    } catch (NumberFormatException e) {
                        System.out.println("Erro ao converter números na linha: " + line);
                        e.printStackTrace();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace(); // Trate a exceção apropriadamente para a sua aplicação
        }
    }

    public void markTaskAsCompletedInFile(Task completedTask) {
        try {
            // Ler todas as linhas do arquivo
            ArrayList<String> lines = new ArrayList<>();
            try (BufferedReader reader = new BufferedReader(new FileReader("tasks.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    lines.add(line);
                }
            }

            // Procurar pela linha correspondente à tarefa concluída e atualizar
            for (int i = 0; i < lines.size(); i++) {
                String[] taskDetails = lines.get(i).split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);

                String taskId = taskDetails[0];

                // Verificar se a linha corresponde à tarefa concluída
                if (Integer.parseInt(taskId) == completedTask.getId()) {
                    // Atualizar a última string para "true"
                    taskDetails[taskDetails.length - 1] = "true";
                    lines.set(i, String.join(",", taskDetails));
                    break;
                }

            }

            // Escrever as linhas atualizadas de volta no arquivo
            try (PrintWriter writer = new PrintWriter(new FileWriter("tasks.txt", false))) {
                for (String line : lines) {
                    writer.println(line);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
            // Trate a exceção apropriadamente para a sua aplicação
        }
    }


    public void addTaskToCompleted(Task completedTask){
        user.addTaskToCompleted(completedTask);
        markTaskAsCompletedInFile(completedTask);
    }

    public void addToOrderedTasks(Task newOrderedTask){
        user.addToOrderedTasks(newOrderedTask);
    }
    public void addToTodayTasks(Task newTodayTask){
        user.addToTodayTasks(newTodayTask);
        saveNewTaskOnFile(newTodayTask);
    }
    public void addToTomorrowTasks(Task newTomorrowTask){
        user.addToTomorrowTasks(newTomorrowTask);
        saveNewTaskOnFile(newTomorrowTask);
    }
    public void addToNoSpecDateTasks(Task newNoSpecDateTask){
        user.addToNoSpecDateTasks(newNoSpecDateTask);
        saveNewTaskOnFile(newNoSpecDateTask);
    }
    public ArrayList<Task> getCompletedTasks(){return user.getCompletedTasks();}
    public ArrayList<Task> getUserOrderedTasks(){return user.getOrderedTasks();}
    public ArrayList<Task> getUserTodayTasks(){return user.getTodayTasks();}
    public ArrayList<Task> getUserTomorrowTasks(){return user.getTomorrowTasks();}
    public ArrayList<Task> getUserNoSpecDateTasks(){return user.getNoSpecDateTasks();}

    public int getStreak() {
        return user.getStreak();
    }

    public void setUserStreak(int newStreak){
        user.setStreak(newStreak);
    }
}
