package com.example.gps_g12.goalTracker.controller;

import com.example.gps_g12.goalTracker.model.fsm.EState;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import com.example.gps_g12.goalTracker.model.ModelManager;

import java.io.IOException;

public class ProfileController {

    ModelManager modelManager;

    @FXML
    private AnchorPane anchorPane;
    
    @FXML
    private Text completedTaskText;

    @FXML
    public void initialize(){
    }


    public void setModelManager(ModelManager modelManager) {
        this.modelManager = modelManager;
        registerHandlers();
        update();
    }

    public void registerHandlers(){
        modelManager.addPropertyChangeListener(evt -> { update(); });
    }

    @FXML
    private void handleBackButton() {
        modelManager.changeState(EState.LIST_TASKS);
    }

    private void updateStreakText(){
        completedTaskText.setText(String.valueOf(modelManager.getStreak()));
    }

    private void update(){

        updateStreakText();

        if (modelManager != null) {
            anchorPane.setVisible(modelManager.getState() == EState.PROFILE);
            completedTaskText.setVisible(modelManager.getState() == EState.PROFILE);
            /*setTask.setVisible(modelManager.getState() == EState.EDIT_TASK);
            cancel.setVisible(modelManager.getState() == EState.EDIT_TASK);
            TaskName.setVisible(modelManager.getState() == EState.EDIT_TASK);
            titledPane.setVisible(modelManager.getState() == EState.EDIT_TASK);
            nameLabel.setVisible(modelManager.getState() == EState.EDIT_TASK);
            dateLabel.setVisible(modelManager.getState() == EState.EDIT_TASK);
            hourLabel.setVisible(modelManager.getState() == EState.EDIT_TASK);
            priorityLabel.setVisible(modelManager.getState() == EState.EDIT_TASK);
            datePicker.setVisible(modelManager.getState() == EState.EDIT_TASK);
            hourTextField.setVisible(modelManager.getState() == EState.EDIT_TASK);*/
        } else {
            anchorPane.setVisible(false);
            completedTaskText.setVisible(false);
            /*setTask.setVisible(false);
            cancel.setVisible(false);
            TaskName.setVisible(false);
            titledPane.setVisible(false);
            nameLabel.setVisible(false);
            dateLabel.setVisible(false);
            hourLabel.setVisible(false);
            priorityLabel.setVisible(false);
            datePicker.setVisible(false);
            hourTextField.setVisible(false);*/
        }

    }

}
