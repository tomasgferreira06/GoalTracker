package com.example.gps_g12.goalTracker.controller;

import com.example.gps_g12.goalTracker.model.ModelManager;
import com.example.gps_g12.goalTracker.model.data.Task;
import com.example.gps_g12.goalTracker.model.fsm.EState;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class EditTaskController {

    ModelManager modelManager;
    Task taskToEdit;

    @FXML
    private Button setTask;
    @FXML
    private Button cancel;
    @FXML
    private TextField TaskName;
    @FXML
    private TitledPane titledPane;
    @FXML
    private Label nameLabel;
    @FXML
    private Label dateLabel;
    @FXML
    private Label hourLabel;
    @FXML
    private Label priorityLabel;
    @FXML
    private DatePicker datePicker;
    @FXML
    private TextField hourTextField;
    @FXML
    private TextField minuteTextField;
    @FXML
    private ChoiceBox<String> priorityChoiceBox;
    @FXML
    private ChoiceBox<String> frequencyChoiceBox;
    @FXML
    private CheckBox reminderButton;
    @FXML
    private TextField TimesPerDay;

    @FXML
    public void initialize(){
    }


    public void setModelManager(ModelManager modelManager) {
        this.modelManager = modelManager;
        registerHandlers();
        update();
    }

    public void registerHandlers(){
        modelManager.addPropertyChangeListener(evt -> { update(); });
    }

    private void update(){
        if (modelManager != null) {
            setTask.setVisible(modelManager.getState() == EState.EDIT_TASK);
            cancel.setVisible(modelManager.getState() == EState.EDIT_TASK);
            TaskName.setVisible(modelManager.getState() == EState.EDIT_TASK);
            titledPane.setVisible(modelManager.getState() == EState.EDIT_TASK);
            nameLabel.setVisible(modelManager.getState() == EState.EDIT_TASK);
            dateLabel.setVisible(modelManager.getState() == EState.EDIT_TASK);
            hourLabel.setVisible(modelManager.getState() == EState.EDIT_TASK);
            priorityLabel.setVisible(modelManager.getState() == EState.EDIT_TASK);
            datePicker.setVisible(modelManager.getState() == EState.EDIT_TASK);
            hourTextField.setVisible(modelManager.getState() == EState.EDIT_TASK);
        } else {
            setTask.setVisible(false);
            cancel.setVisible(false);
            TaskName.setVisible(false);
            titledPane.setVisible(false);
            nameLabel.setVisible(false);
            dateLabel.setVisible(false);
            hourLabel.setVisible(false);
            priorityLabel.setVisible(false);
            datePicker.setVisible(false);
            hourTextField.setVisible(false);
        }

    }

    @FXML
    private void setEditedTask(){

    }

    public void backToListTasks() {
        modelManager.changeState(EState.LIST_TASKS);
    }

    public Task getTaskToEdit() {
        return taskToEdit;
    }

    public void setTaskToEdit(Task taskToEdit) {
        this.taskToEdit = taskToEdit;

        //set the rest of the properties
        TaskName.setText(taskToEdit.getName());

        if(!taskToEdit.getDate().toString().equals("0/0/0")){
            LocalDate stringToDate = LocalDate.parse(taskToEdit.getDate().toString(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            datePicker.setValue(stringToDate);
        }

        hourTextField.setText(String.valueOf(taskToEdit.getHour().getHours()));
        minuteTextField.setText(String.valueOf(taskToEdit.getHour().getMinutes()));
        priorityChoiceBox.setValue(taskToEdit.getPriority());
        frequencyChoiceBox.setValue(taskToEdit.getFrequency());
        reminderButton.setSelected(taskToEdit.getReminder());
        TimesPerDay.setText(String.valueOf(taskToEdit.getTimesPerDay()));
    }
}
